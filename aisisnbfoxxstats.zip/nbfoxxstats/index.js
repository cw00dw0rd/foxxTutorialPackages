'use strict';
const { aql, query, db } = require("@arangodb");
const createRouter = require('@arangodb/foxx/router');
const users = require("@arangodb/users");

const router = createRouter();
const joi = require('joi');

const collectionName = db._collection("tutorialInstances");

module.context.use(router);

router.get('/tutorialStats', function (req,res) {

    let stats = query`
    LET expired = (
        FOR doc IN expiredtutorialInstances
         RETURN {
         TutorialName: doc.tutorialName,
         Timestamp: doc.timestamp
         }
        )
        
       LET active = (
        FOR doc IN tutorialInstances
         RETURN {
         TutorialName: doc.tutorialName,
         Timestamp: doc.timestamp
         }
        )
        
       RETURN [expired, active]`

    res.send({stats});
  })
.response(joi.object().required(), 'Returns notebook stats as nested array')
.summary('queries for a records of notebooks and returns all stored information.')
.description('Queries both the expired and active notebook collections. Returns the creation timestamps and associated notebook name ');

router.get('/aisisStats', function (req,res) {

    let stats = query`
    LET expired = (
        FOR doc IN expiredaisisInstances
         RETURN {
         TutorialName: doc.tutorialName,
         Timestamp: doc.timestamp
         }
        )
        
       LET active = (
        FOR doc IN aisisInstances
         RETURN {
         TutorialName: doc.tutorialName,
         Timestamp: doc.timestamp
         }
        )
        
       RETURN [expired, active]`

    res.send({stats});
  })
.response(joi.object().required(), 'Returns notebook stats as nested array')
.summary('queries for a records of notebooks and returns all stored information.')
.description('Queries both the expired and active notebook collections. Returns the creation timestamps and associated notebook name ');


  