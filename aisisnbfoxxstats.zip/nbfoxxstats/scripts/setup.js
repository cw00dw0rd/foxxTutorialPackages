'use strict';
const db = require('@arangodb').db;
const aisisName = 'aisisInstances';
const collectionName = 'tutorialInstances';
const expiredCollectionName = "expired"+collectionName;
const expiredaisisName = "expired"+aisisName;

// Creates collection to hold current user and instance information, to be deleted
if (!db._collection(collectionName)) {
  db._createDocumentCollection(collectionName);
}
// Creates collection to hold expired documents
if (!db._collection(expiredCollectionName)) {
  db._createDocumentCollection(expiredCollectionName);
}

// Creates collection to hold current user and instance information, to be deleted
if (!db._collection(aisisName)) {
  db._createDocumentCollection(aisisNameName);
}
// Creates collection to hold expired documents
if (!db._collection(expiredaisisName)) {
  db._createDocumentCollection(expiredaisisNameName);
}
